import React, { useState } from 'react';
import './Barberek.css';

const Barberek = ({ onOpenAuth }) => {
  // Állapotok (State-ek) a kiválasztáshoz
  const [selectedBarber, setSelectedBarber] = useState(null); // Melyik fodrászra kattintott?
  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    service_id: 1 // Alapértelmezetten az 1-es szolgáltatás
  });

  const barbers = [
    {
      id: 1,
      name: "Kovács Dávid",
      role: "Master Barber",
      desc: "10 év tapasztalattal a klasszikus vágások szakértője.",
      image: "https://cdn.britannica.com/65/227665-050-D74A477E/American-actor-Leonardo-DiCaprio-2016.jpg" 
    },
    {
      id: 2,
      name: "Nagy Aliz",
      role: "Szakáll Specialista",
      desc: "Forró törölközős borotválásban verhetetlen.",
      image: "https://s.yimg.com/ny/api/res/1.2/ABv9asL4IBaRBtZ9zzZh1A--/YXBwaWQ9aGlnaGxhbmRlcjt3PTIwMDA7aD0xMzAwO2NmPXdlYnA-/https://media.zenfs.com/en/bang_showbiz_628/24d634077ef83b1e61a8e8cce1883aac"
    },
    {
      id: 3,
      name: "Szabó Péter",
      role: "Modern Stylist",
      desc: "A legújabb trendek követője.",
      image: "https://assets.fxnetworks.com/fx/950c40a9-c758-426a-a2f9-be192d3fc395.jpg" 
    }
  ];

  // Ez fut le, amikor rányomnak a "Véglegesítés" gombra
  const handleBooking = async () => {
    // Ellenőrzés: töltött-e ki mindent?
    if (!bookingData.date || !bookingData.time) {
      alert("Kérlek válassz dátumot és időpontot!");
      return;
    }

    // Az adatok, amit a PHP vár
    const payload = {
      user_id: 1, // TESZT MIATT: Fixen 1-es user
      employee_id: selectedBarber.id,
      service_id: bookingData.service_id,
      date: bookingData.date,
      time: bookingData.time
    };

    try {
      const response = await fetch('http://localhost/barbershop-backend/booking.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (data.success) {
        alert("✅ Sikeres foglalás: " + data.message);
        setSelectedBarber(null); // Bezárjuk az ablakot
      } else {
        alert("❌ Hiba: " + data.message);
      }
    } catch (error) {
      console.error("Hiba:", error);
      alert("Nem sikerült elérni a szervert.");
    }
  };

  return (
    <div className="barbers-container">
      <h2>Ismerd meg csapatunkat</h2>
      <p className="subtitle">Válassz szakembert és foglalj időpontot!</p>

      <div className="barbers-list">
        {barbers.map((barber) => (
          <div key={barber.id} className="barber-card">
            <div className="barber-image-wrapper">
              <img src={barber.image} alt={barber.name} className="barber-img" />
            </div>
            <div className="barber-info">
              <h3>{barber.name}</h3>
              <span className="role">{barber.role}</span>
              <p>{barber.desc}</p>
              
              <button 
                className="book-barber-btn" 
                onClick={() => setSelectedBarber(barber)}
              >
                Időpontfoglalás
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* --- MODAL (JAVÍTOTT NEVEKKEL) --- */}
      {selectedBarber && (
        <div className="booking-modal-overlay"> {/* ITT VAN A JAVÍTÁS */}
          <div className="booking-modal-content"> {/* ITT VAN A JAVÍTÁS */}
            <h3>Foglalás: {selectedBarber.name}</h3>
            
            <label>Dátum:</label>
            <input 
              type="date" 
              onChange={(e) => setBookingData({...bookingData, date: e.target.value})}
            />

            <label>Időpont:</label>
            <input 
              type="time" 
              onChange={(e) => setBookingData({...bookingData, time: e.target.value})}
            />

            <label>Szolgáltatás:</label>
            <select onChange={(e) => setBookingData({...bookingData, service_id: e.target.value})}>
                <option value="1">Hajvágás</option>
                <option value="2">Szakálligazítás</option>
            </select>

            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setSelectedBarber(null)}>Mégse</button>
              <button className="confirm-btn" onClick={handleBooking}>Lefoglalás</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Barberek;