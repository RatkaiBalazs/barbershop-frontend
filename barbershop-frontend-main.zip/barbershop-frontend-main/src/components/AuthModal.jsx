import React, { useState } from 'react';
import './AuthModal.css';

const AuthModal = ({ onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  
  // Állapot a jelszó láthatóságához (false = rejtett, true = látható)
  const [showPassword, setShowPassword] = useState(false);

  // Űrlap adatok
  const [formData, setFormData] = useState({
    lastname: '',
    firstname: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const [error, setError] = useState('');

  // Mezők változásának kezelése
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };

  // --- ŰRLAP BEKÜLDÉSE (Regisztráció vagy Belépés) ---
  const handleSubmit = async (e) => {
    e.preventDefault();

    // 1. HA REGISZTRÁCIÓ VAN:
    if (!isLogin) {
      if (formData.password !== formData.confirmPassword) {
        setError('A két jelszó nem egyezik meg!');
        return;
      }

      const payload = {
        nev: `${formData.lastname} ${formData.firstname}`,
        email: formData.email,
        telszam: formData.phone,
        jelszo: formData.password
      };

      try {
        // Regisztrációs kérés küldése a Backendnek
        const response = await fetch('http://localhost/Barbershop_Backend/register.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
          alert('✅ Sikeres regisztráció! Most már bejelentkezhetsz.');
          setIsLogin(true); // Átváltunk belépés nézetre
        } else {
          setError(data.message);
        }
      } catch (err) {
        console.error("Hiba:", err);
        setError('Nem sikerült elérni a szervert (Regisztráció). Ellenőrizd a XAMPP-ot!');
      }

    } else { 
      // 2. HA BEJELENTKEZÉS VAN:
      
      const payload = {
        email: formData.email,
        password: formData.password
      };

      try {
        // Belépési kérés küldése a Backendnek
        const response = await fetch('http://localhost/Barbershop_Backend/login.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
          // SIKER!
          // 1. Elmentjük a felhasználót a böngészőbe (LocalStorage)
          localStorage.setItem('user', JSON.stringify(data.user));
          
          alert('Sikeres bejelentkezés! Üdv, ' + data.user.name);
          
          // 2. Bezárjuk az ablakot és frissítjük az oldalt
          onClose(); 
          window.location.reload(); 
        } else {
          // HIBA (pl. rossz jelszó)
          setError(data.message);
        }

      } catch (err) {
        console.error("Hiba:", err);
        setError('Nem sikerült elérni a szervert (Belépés). Ellenőrizd a XAMPP-ot!');
      }
    }
  };

  const switchMode = () => {
    setIsLogin(!isLogin);
    setError('');
    setShowPassword(false); // Váltáskor mindig rejtsük vissza a jelszót
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        
        <button className="close-btn" onClick={onClose}>&times;</button>
        
        <h2>{isLogin ? 'Bejelentkezés' : 'Regisztráció'}</h2>
        
        <p>
          {isLogin 
            ? 'Jelentkezz be az időpontfoglaláshoz!' 
            : 'Add meg adataidat a regisztrációhoz!'}
        </p>

        {error && <div className="error-message" style={{color: 'red', fontWeight: 'bold', marginBottom: '10px'}}>{error}</div>}
        
        <form className="auth-form" onSubmit={handleSubmit}>
          
          {/* --- CSAK REGISZTRÁCIÓNÁL LÁTHATÓ MEZŐK --- */}
          {!isLogin && (
            <>
              <div className="name-row">
                <div className="form-group">
                  <label>Vezetéknév</label>
                  <input type="text" name="lastname" placeholder="Kovács" onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label>Keresztnév</label>
                  <input type="text" name="firstname" placeholder="János" onChange={handleChange} required />
                </div>
              </div>

              <div className="form-group">
                <label>Telefonszám</label>
                <input type="tel" name="phone" placeholder="+36 30 123 4567" onChange={handleChange} required />
              </div>
            </>
          )}

          {/* --- KÖZÖS MEZŐK (EMAIL, JELSZÓ) --- */}
          <div className="form-group">
            <label>Email cím</label>
            <input type="email" name="email" placeholder="pelda@email.com" onChange={handleChange} required />
          </div>
          
          <div className="form-group">
            <label>Jelszó</label>
            <div className="password-wrapper">
              <input 
                type={showPassword ? "text" : "password"} 
                name="password" 
                placeholder="********" 
                onChange={handleChange} 
                required 
              />
              {/* Szem ikon a jelszó megjelenítéséhez */}
              <span 
                className="password-toggle-icon" 
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? "Jelszó elrejtése" : "Jelszó megjelenítése"}
              >
                {showPassword ? (
                   <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                ) : (
                   <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
                )}
              </span>
            </div>
          </div>

          {/* JELSZÓ MEGERŐSÍTÉS (Csak regisztrációnál) */}
          {!isLogin && (
            <div className="form-group">
              <label>Jelszó megerősítése</label>
              <div className="password-wrapper">
                <input 
                  type={showPassword ? "text" : "password"} 
                  name="confirmPassword" 
                  placeholder="********" 
                  onChange={handleChange} 
                  required 
                  style={{ borderColor: error && error.includes('jelszó') ? 'red' : '#ccc' }}
                />
              </div>
            </div>
          )}
          
          <button type="submit" className="login-btn">
            {isLogin ? 'Belépés' : 'Regisztráció'}
          </button>
        </form>

        <p className="switch-text">
          {isLogin ? 'Még nincs fiókod?' : 'Már van fiókod?'} 
          <span className="link" onClick={switchMode}>
            {isLogin ? ' Regisztráció' : ' Belépés'}
          </span>
        </p>

      </div>
    </div>
  );
};

export default AuthModal;